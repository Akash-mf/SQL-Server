-- Create a trigger to add new score events to existing player score
-- Every time a new score event is recorded, the Players table should be updated as well

SELECT * FROM Game.ScoreEvents;
SELECT * FROM Game.Players;
GO


