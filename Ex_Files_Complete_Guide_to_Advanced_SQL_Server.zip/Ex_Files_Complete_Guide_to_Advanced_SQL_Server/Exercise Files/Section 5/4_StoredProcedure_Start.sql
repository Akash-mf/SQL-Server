-- Goal: Keep a permanent record of the global score as it changes throughout the life of the game.
-- Tasks:
-- 1) Create an Append-Only Ledger Table to store the global score log. Name it Game.ScoreLedger.
-- 2) Write a Stored Procedure to log the current global score to Game.ScoreLedger
-- 3) Create a trigger that will record the current global score any time an update occurs on the Players table

-- Create ledger table


-- Create the stored procedure to populate ledger table


-- Execute and test the procedure


-- Create trigger to record the global score whenever Players table is updated


-- Test the trigger
