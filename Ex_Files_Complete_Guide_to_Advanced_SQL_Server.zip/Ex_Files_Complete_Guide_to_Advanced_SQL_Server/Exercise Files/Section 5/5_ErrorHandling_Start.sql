-- Add error handling and test the system

-- Test with known-good scenario
INSERT INTO Game.ScoreEvents (PlayerID, Score) VALUES
    (2, 125);

SELECT * FROM Game.ScoreEvents;
SELECT * FROM Game.Players;
SELECT * FROM Game.ScoreLedger;


-- Test with negative score



-- Test with invalid multiple inserts



 -- Test with invalid PlayerID


