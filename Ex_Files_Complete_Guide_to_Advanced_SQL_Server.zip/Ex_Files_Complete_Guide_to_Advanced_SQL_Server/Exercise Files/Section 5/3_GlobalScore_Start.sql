-- Write a custom function to calculate global score total.
-- This consists of the sum total of all player's current score * bonus multiplier

-- Review current data
SELECT * FROM Game.Players;
GO

