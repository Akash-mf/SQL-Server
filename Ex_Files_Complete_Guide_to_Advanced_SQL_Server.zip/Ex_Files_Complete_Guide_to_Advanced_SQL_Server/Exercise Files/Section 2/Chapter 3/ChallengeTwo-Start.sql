USE KinetEcoTRG;
GO

/* Create a trigger that fires on all table events.
   The trigger needs to save information from EVENTDATA()
   about these elements: EventType, UserName, ObjectName, TSQLCommand.

INSERT YOUR SOLUTION HERE */







/* TEST SOLUTION */
CREATE TABLE dbo.SolutionTest (
    RowID int IDENTITY PRIMARY KEY
);
GO

ALTER TABLE dbo.SolutionTest ADD
    RowText nvarchar(20),
    RowNumber int
;
GO

ALTER TABLE dbo.SolutionTest DROP COLUMN RowNumber;

DROP TABLE dbo.SolutionTest;

/* VIEW RESULTS */
SELECT * FROM {EventCaptureTableName};


/* CLEAN THE SERVER WHEN COMPLETE */
DROP TRIGGER {YourTriggerName}
ON DATABASE;
DROP TABLE {YourEventCaptureTableName};
GO