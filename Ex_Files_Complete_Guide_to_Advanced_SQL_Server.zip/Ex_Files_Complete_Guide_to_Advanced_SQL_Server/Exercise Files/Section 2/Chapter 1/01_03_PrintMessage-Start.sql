USE KinetEcoTRG;
GO

CREATE TABLE dbo.Products (
    ProductID int PRIMARY KEY,
    ProductName nvarchar(50)
);
GO

INSERT INTO dbo.Products
VALUES
   (1, '9 Volt Battery');
GO