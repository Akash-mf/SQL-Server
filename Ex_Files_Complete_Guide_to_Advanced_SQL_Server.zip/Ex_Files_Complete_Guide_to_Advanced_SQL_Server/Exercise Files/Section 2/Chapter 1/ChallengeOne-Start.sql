USE KinetEcoTRG;
GO

CREATE TABLE dbo.ProductCategories (
    CategoryID int IDENTITY PRIMARY KEY,
    CategoryName nvarchar(20),
    CreationDate datetime2,
    LastModifiedDate datetime2
);
GO

/* INSERT YOUR SOLUTION HERE */




/* TEST SOLUTION */
INSERT INTO dbo.ProductCategories (CategoryName)
VALUES
    ('Solar Panel'), ('Battery'), ('Wind Harvester')
;

UPDATE dbo.ProductCategories
SET CategoryName = 'Wind Turbine'
WHERE CategoryID = 3
;

DELETE FROM dbo.ProductCategories
WHERE CategoryID = 2;

SELECT * FROM dbo.ProductCategories;

/* REMOVE ProductCategories TABLE WHEN COMPLETE */
DROP TABLE dbo.ProductCategories;
GO