CREATE DATABASE KinetEco;
GO

USE KinetEco;
GO

CREATE SCHEMA Finance;
GO


-- Create an append-only ledger table
CREATE TABLE Finance.TaxID
(
    CustomerID INT NOT NULL PRIMARY KEY CLUSTERED,
    TaxID VARCHAR (50) NOT NULL,
)
WITH 
(
 LEDGER = ON (APPEND_ONLY = ON)
);


-- Add data to the table
INSERT INTO Finance.TaxID VALUES
(1, '000-12-3456'),
(2, '123-45-6789'),
(3, '987-65-4321'),
(4, '001-02-0345');

SELECT * FROM Finance.TaxID;

-- Attempt to update a row
UPDATE Finance.TaxID
SET TaxID = '999-99-9999'
WHERE CustomerID = 3;

-- Attempt to delete a row
DELETE FROM Finance.TaxID
WHERE CustomerID = 3;


-- Drop the entire table
DROP TABLE Finance.TaxID

-- Data is not removed from the database,
-- instead, it is moved to the Dropped Ledger Tables folder