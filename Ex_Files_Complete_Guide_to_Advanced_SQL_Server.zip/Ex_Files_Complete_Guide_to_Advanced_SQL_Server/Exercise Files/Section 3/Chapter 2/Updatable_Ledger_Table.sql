CREATE DATABASE KinetEco;
GO

USE KinetEco;
GO

CREATE SCHEMA Finance;
GO


-- Create an updatable ledger table
CREATE TABLE Finance.Accounts
(
    CustomerID INT NOT NULL PRIMARY KEY CLUSTERED,
    FirstName VARCHAR (50) NOT NULL,
    Balance DECIMAL (10,2) NOT NULL
)
WITH 
(
 SYSTEM_VERSIONING = ON (HISTORY_TABLE = Finance.AccountsHistory),
 LEDGER = ON
);


-- Add data to the table
INSERT INTO Finance.Accounts VALUES
(1, 'Ruiz', 50.00),
(2, 'Katherine', 100.00),
(3, 'Mica', 80.00),
(4, 'Shannon', 75.00);

-- Update Katherine's balance
UPDATE Finance.Accounts
SET Balance = 60.00 
WHERE CustomerID = 2;


-- Query the current state of the data
SELECT * FROM Finance.Accounts;          -- Ledger Table (current state of data)

SELECT CustomerID                        -- Expose additional "Generated Always" columns
   ,FirstName
   ,Balance
   ,ledger_start_transaction_id
   ,ledger_end_transaction_id
   ,ledger_start_sequence_number
   ,ledger_end_sequence_number
 FROM Finance.Accounts;  


-- When you create an updatable ledger table, the history and view are also created
SELECT * FROM Finance.AccountsHistory;   -- Ledger History (prior states of data)

SELECT * FROM Finance.Accounts_Ledger
    ORDER BY ledger_transaction_id, ledger_sequence_number;  -- Ledger View (combined view of all data past and present)