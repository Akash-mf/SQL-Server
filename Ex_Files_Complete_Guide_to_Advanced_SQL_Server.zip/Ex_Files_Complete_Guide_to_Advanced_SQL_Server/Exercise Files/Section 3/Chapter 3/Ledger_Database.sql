-- Create a Ledger Database
CREATE DATABASE KinetEcoLedgerDB
WITH LEDGER = ON;
GO

USE KinetEcoLedgerDB;
GO

-- Create a table
CREATE SCHEMA Products;
GO

CREATE TABLE Products.Inventory (
    ProductID INT NOT NULL PRIMARY KEY CLUSTERED,
    ProductName VARCHAR (50) NOT NULL,
    Price DECIMAL (10,2) NOT NULL
);


-- Add products to the table
INSERT INTO Products.Inventory VALUES 
    (100, 'Solar Charger', 59.99),
    (110, 'USB Battery Bank', 129.99)
;

SELECT * FROM Products.Inventory;