-- Creating Ledger Digests in SQL Server 2022
USE KinetEco;
GO

------------------------------------------------------------------
-- Option 1) Enable automatic Digest creation and storage on Azure
    -- Prerequisites on Azure: 
        -- Create a named Azure Storage Container, ie 'sqldbledgerdigests'
        -- Create policy with Read, Add, Create, Write, and List permissions
        -- Generate a shared access signature key
    
    -- Create a credential on SQL Server using the container, signature, and policy
CREATE CREDENTIAL [https://ledgerstorage.blob.core.windows.net/sqldbledgerdigests]  
  WITH IDENTITY='SHARED ACCESS SIGNATURE',  
  SECRET = 'sr=c&si=<MYPOLICYNAME>&sig=<THESHAREDACCESSSIGNATURE>';

    -- Enable Digest uploads
ALTER DATABASE SCOPED CONFIGURATION
  SET LEDGER_DIGEST_STORAGE_ENDPOINT = 'https://ledgerstorage.blob.core.windows.net';


------------------------------------------------------------------
 -- Option 2) Generate and save Digest files manually

EXECUTE sp_generate_database_ledger_digest;

    -- The result of the stored procedure can be save as a JSON data file


------------------------------------------------------------------
-- Update the database and create another Digest
UPDATE Finance.Accounts
  SET Balance = 98.00 
  WHERE CustomerID = 3;

EXECUTE sp_generate_database_ledger_digest;