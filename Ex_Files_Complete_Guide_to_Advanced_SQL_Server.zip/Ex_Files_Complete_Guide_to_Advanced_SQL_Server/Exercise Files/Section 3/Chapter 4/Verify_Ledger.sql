-- Verify the database has not been tampered with using Ledger Digests
USE KinetEco;
GO


-- Ledger Verification requires Snapshot Isolation
ALTER DATABASE KinetEco  
SET ALLOW_SNAPSHOT_ISOLATION ON;


-- Verify ledger database - success due to actual hash saved in Digest
EXECUTE sp_verify_database_ledger N'
[
  {
    "database_name":"KinetEco",
    "block_id":1,
    "hash":"0xDBDD8A92CCEE7F9E6E8564A10F2B0F2228A461FACFDC3A5EEE4094519D9B7A61",
    "last_transaction_commit_time":"2023-03-03T11:53:22.2833333",
    "digest_time":"2023-03-03T20:52:59.2210601"
  }
]';


-- Verify ledger database - will fail due to unmatched hash
EXECUTE sp_verify_database_ledger N'
[
  {
    "database_name":"KinetEco",
    "block_id":1,
    "hash":"0xDBDD8A92CCEE7F9E6E8564A10F2B0F2228A461FACFDC3A5EEE4094519D9B7A00",
    "last_transaction_commit_time":"2023-03-03T11:53:22.2833333",
    "digest_time":"2023-03-03T20:52:59.2210601"
  }
]';


-- Verify ledger database using automatic digest storage
DECLARE @digest_locations NVARCHAR(MAX) = (SELECT * FROM sys.database_ledger_digest_locations FOR JSON AUTO, INCLUDE_NULL_VALUES);
SELECT @digest_locations as digest_locations;
BEGIN TRY
    EXEC sys.sp_verify_database_ledger_from_digest_storage @digest_locations;
    SELECT 'Ledger verification succeeded.' AS Result;
END TRY
BEGIN CATCH
    THROW;
END CATCH