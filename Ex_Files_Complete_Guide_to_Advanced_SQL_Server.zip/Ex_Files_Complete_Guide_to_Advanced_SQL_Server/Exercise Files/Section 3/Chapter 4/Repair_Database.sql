USE KinetEco;
GO

-- View information about each closed ledger block
SELECT * FROM sys.database_ledger_blocks

-- View information about individual transactions contained in the ledger
SELECT * FROM sys.database_ledger_transactions