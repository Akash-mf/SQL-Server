USE KinetEco;
GO

-- Original insert statement that added values to the Accounts table
INSERT INTO Finance.Accounts VALUES
(1, 'Ruiz', 50.00),
(2, 'Katherine', 100.00),
(3, 'Mica', 80.00),
(4, 'Shannon', 75.00);

-- The original inserts occured in transaction ID 957


-- After maliciously tampering with the database file, the data is now different
SELECT * FROM Finance.Accounts;

-- Now take a look at the History table. There are no edits to Ruiz's record.
SELECT * FROM Finance.AccountsHistory;

-- Investigate the Ledger View to see the transactional history of the table
SELECT * FROM Finance.Accounts_Ledger
    ORDER BY ledger_transaction_id, ledger_sequence_number;

-- None of these tables show any overt signs of data tampering. 
-- The Ledger Digest is the only way to discover the tampering.

-- Verify the ledgers consistency by comparing it to the previously exported Digest
EXECUTE sp_verify_database_ledger N'
[
  {
    "database_name":"KinetEco",
    "block_id":1,
    "hash":"0xDBDD8A92CCEE7F9E6E8564A10F2B0F2228A461FACFDC3A5EEE4094519D9B7A61",
    "last_transaction_commit_time":"2023-03-03T11:53:22.2833333",
    "digest_time":"2023-03-03T20:52:59.2210601"
  }
]';